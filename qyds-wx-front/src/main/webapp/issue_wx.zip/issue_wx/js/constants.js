//图片显示的URI
var DISPLAY_URI ;

//库存限制
var BnkLimit20 ;
var BnkLimit50 ;

//原图
var ORIGNAL = "/orignal";
//缩略图
var THUMB_120 = "/thumb120";
//缩略图
var THUMB_480 = "/thumb480";
//缩略图
var THUMB_800 = "/thumb800";
//缩略图
var THUMB_1200 = "/thumb1200";

// localstorage key
var KEY_USERID = "key_userId";
var KEY_OPENID = "key_openId";
var KEY_USERINFO = "key_userInfo";
