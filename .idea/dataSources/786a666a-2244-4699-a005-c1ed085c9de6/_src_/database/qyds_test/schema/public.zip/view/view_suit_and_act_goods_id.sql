CREATE VIEW view_suit_and_act_goods_id AS SELECT suit.goods_id,
    suit.type,
    suit.brand_id,
    suit.goods_type_id,
    suit.goods_name,
    activity.actition_type,
    activity.activity_id,
    suit.goods_code,
    suit.search_key,
    suit.image_url_json,
    suit.update_time
   FROM ( SELECT master.goods_id,
            master.type,
            master.brand_id,
            master.goods_type_id,
            master.goods_name,
            master.goods_code,
            detail.search_key,
            detail.image_url_json,
            master.update_time
           FROM (gds_master master
             LEFT JOIN gds_detail detail ON ((((master.goods_id)::text = (detail.goods_id)::text) AND ((detail.deleted)::text = '0'::text))))
          WHERE ((((master.type)::text = '30'::text) AND ((master.deleted)::text = '0'::text)) AND ((master.is_onsell)::text = '0'::text))) suit,
    ( SELECT am.activity_id,
            am.activity_name,
            am.goods_type,
            am.member_type,
            template.actition_type,
            ag.goods_id AS act_goods_id,
            ag.sku_id AS act_sku_id
           FROM ((act_master am
             LEFT JOIN act_goods ag ON (((am.activity_id)::text = (ag.activity_id)::text)))
             LEFT JOIN act_template template ON (((template.temp_id)::text = (am.temp_id)::text)))
          WHERE ((((((am.goods_type)::text = '10'::text) AND ((am.approve_status)::text = '20'::text)) AND (am.start_time <= now())) AND (am.end_time >= now())) AND ((am.deleted)::text = '0'::text))) activity
UNION
 SELECT suit.goods_id,
    suit.type,
    suit.brand_id,
    suit.goods_type_id,
    suit.goods_name,
    activity.actition_type,
    activity.activity_id,
    suit.goods_code,
    suit.search_key,
    suit.image_url_json,
    suit.update_time
   FROM ( SELECT master.goods_id,
            master.type,
            master.brand_id,
            master.goods_type_id,
            master.goods_name,
            master.goods_code,
            detail.search_key,
            detail.image_url_json,
            master.update_time
           FROM (gds_master master
             LEFT JOIN gds_detail detail ON ((((master.goods_id)::text = (detail.goods_id)::text) AND ((detail.deleted)::text = '0'::text))))
          WHERE ((((master.type)::text = '30'::text) AND ((master.deleted)::text = '0'::text)) AND ((master.is_onsell)::text = '0'::text))) suit,
    ( SELECT am.activity_id,
            am.activity_name,
            am.goods_type,
            am.member_type,
            template.actition_type,
            ag.goods_id AS act_goods_id
           FROM ((act_master am
             LEFT JOIN act_goods ag ON (((am.activity_id)::text = (ag.activity_id)::text)))
             LEFT JOIN act_template template ON (((template.temp_id)::text = (am.temp_id)::text)))
          WHERE ((((((ag.goods_type)::text = '20'::text) AND ((am.approve_status)::text = '20'::text)) AND (am.start_time <= now())) AND (am.end_time >= now())) AND ((am.deleted)::text = '0'::text))) activity
UNION
 SELECT suit.goods_id,
    suit.type,
    suit.brand_id,
    suit.goods_type_id,
    suit.goods_name,
    activity.actition_type,
    activity.activity_id,
    suit.goods_code,
    suit.search_key,
    suit.image_url_json,
    suit.update_time
   FROM ( SELECT master.goods_id,
            master.type,
            master.brand_id,
            master.goods_type_id,
            master.goods_name,
            master.goods_code,
            detail.search_key,
            detail.image_url_json,
            master.update_time
           FROM (gds_master master
             LEFT JOIN gds_detail detail ON ((((master.goods_id)::text = (detail.goods_id)::text) AND ((detail.deleted)::text = '0'::text))))
          WHERE ((((master.type)::text = '30'::text) AND ((master.deleted)::text = '0'::text)) AND ((master.is_onsell)::text = '0'::text))) suit,
    ( SELECT am.activity_id,
            am.activity_name,
            am.goods_type,
            am.member_type,
            template.actition_type,
            ag.goods_id AS act_goods_id
           FROM ((act_master am
             LEFT JOIN act_goods ag ON (((am.activity_id)::text = (ag.activity_id)::text)))
             LEFT JOIN act_template template ON (((template.temp_id)::text = (am.temp_id)::text)))
          WHERE ((((((ag.goods_type)::text = '30'::text) AND ((am.approve_status)::text = '20'::text)) AND (am.start_time <= now())) AND (am.end_time >= now())) AND ((am.deleted)::text = '0'::text))) activity
UNION
 SELECT suit.goods_id,
    suit.type,
    suit.brand_id,
    suit.goods_type_id,
    suit.goods_name,
    activity.actition_type,
    activity.activity_id,
    suit.goods_code,
    suit.search_key,
    suit.image_url_json,
    suit.update_time
   FROM ( SELECT master.goods_id,
            master.type,
            master.brand_id,
            master.goods_type_id,
            master.goods_name,
            master.goods_code,
            detail.search_key,
            detail.image_url_json,
            master.update_time
           FROM (gds_master master
             LEFT JOIN gds_detail detail ON ((((master.goods_id)::text = (detail.goods_id)::text) AND ((detail.deleted)::text = '0'::text))))
          WHERE ((((master.type)::text = '30'::text) AND ((master.deleted)::text = '0'::text)) AND ((master.is_onsell)::text = '0'::text))) suit,
    ( SELECT am.activity_id,
            am.activity_name,
            am.goods_type,
            am.member_type,
            template.actition_type,
            ag.goods_id AS act_goods_id
           FROM ((act_master am
             LEFT JOIN act_goods ag ON (((am.activity_id)::text = (ag.activity_id)::text)))
             LEFT JOIN act_template template ON (((template.temp_id)::text = (am.temp_id)::text)))
          WHERE ((((((ag.goods_type)::text = '40'::text) AND ((am.approve_status)::text = '20'::text)) AND (am.start_time <= now())) AND (am.end_time >= now())) AND ((am.deleted)::text = '0'::text))) activity
  WHERE ((activity.act_goods_id)::text = (suit.goods_id)::text);
