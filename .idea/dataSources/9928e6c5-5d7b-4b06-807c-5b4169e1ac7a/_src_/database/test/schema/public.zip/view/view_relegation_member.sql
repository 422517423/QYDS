CREATE VIEW view_relegation_member AS SELECT member.member_id,
    master.member_level_id AS current_level_id,
    mlr.member_level_code AS approval_level_id,
    mlr.point_lower,
    member.all_point
   FROM ((( SELECT mmb_point_record.member_id,
            sum(mmb_point_record.point) AS all_point
           FROM mmb_point_record
          WHERE (((mmb_point_record.rule_id)::text = '10'::text) AND (date_part('year'::text, mmb_point_record.point_time) = (date_part('year'::text, now()) - (1)::double precision)))
          GROUP BY mmb_point_record.member_id) member
     JOIN mmb_master master ON ((((master.member_id)::text = (member.member_id)::text) AND ((master.deleted)::text = '0'::text) AND ((master.member_level_id)::text <> '10'::text))))
     JOIN mmb_level_rule mlr ON ((((master.member_level_id)::text >= (mlr.member_level_code)::text) AND ((member.all_point)::numeric >= ((mlr.point_lower)::numeric * 0.8)))));
