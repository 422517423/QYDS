create function filterrefundorder(param character) returns numeric
LANGUAGE plpgsql
AS $$
-- 返回值
declare maxAmount numeric = 0;
-- 定义循环变量
declare var1 numeric;
declare var2 numeric;
declare var3 numeric;

begin
	-- 创建临时表, 存储数据
	drop table if exists zAmount;
	create temporary table zAmount (amount numeric);
    
  	FOR var1 IN (SELECT amount FROM public.erp_order_master where member_code = param and amount > 0) LOOP
    	FOR var2 IN (SELECT amount FROM public.erp_order_master where member_code = param and amount < 0) LOOP
            if ((var1 + var2) != 0) then  
            	insert into zAmount values (var1); 
            end if;
        end loop;
  	end loop;
    -- 从临时表中获取最大值
    FOR var3 IN (SELECT case when max(amount) > 0 then max(amount) else 0 end FROM zAmount) LOOP
        maxAmount = var3;
    end loop;
    
    -- 删除临时表
	drop table if exists zAmount;
    return maxAmount;
end;
$$;
