create view view_onsell_sku_new2 as
  SELECT master.goods_id,
    master.type,
    master.brand_id,
    master.goods_type_id,
    master.is_onsell,
    master.goods_name,
    master.goods_code,
    master.goods_type_name_path,
    sku.goods_sku_id AS skuid,
    sku.sku AS skucontent,
    sku.colore_code AS color_code,
    sku.colore_name AS color_name,
    sku.price,
    sku.safe_bank,
    ''::character varying AS size_code,
    master.update_time
   FROM (gds_sku sku
     LEFT JOIN gds_master master ON (((sku.goods_id)::text = (master.goods_id)::text)))
  WHERE (((sku.deleted)::text = '0'::text) AND ((master.deleted)::text = '0'::text))
UNION ALL
 SELECT master.goods_id,
    master.type,
    erpgoods.brand_code AS brand_id,
    master.goods_type_id,
    master.is_onsell,
    master.goods_name,
    master.goods_code,
    master.goods_type_name_path,
    erpgoods.sku AS skuid,
    ''::text AS skucontent,
    erpgoods.color_code,
    erpgoods.color_name,
    erpgoods.price,
    999999 AS safe_bank,
    erpgoods.size_code,
    master.update_time
   FROM (erp_goods erpgoods
     LEFT JOIN gds_master master ON (((erpgoods.goods_code)::text = (master.erp_goods_code)::text)))
  WHERE ((master.deleted)::text = '0'::text);

