create view view_com_district_fullname as
  WITH RECURSIVE m AS (
         SELECT com_district.district_id,
            com_district.parent_id,
            com_district.district_name,
            (com_district.district_name)::text AS district_full_name
           FROM com_district
          WHERE ((com_district.parent_id)::text = '0'::text)
        UNION ALL
         SELECT s.district_id,
            s.parent_id,
            s.district_name,
            ((m_1.district_full_name || '/'::text) || (s.district_name)::text) AS district_full_name
           FROM (com_district s
             JOIN m m_1 ON (((s.parent_id)::text = (m_1.district_id)::text)))
        )
 SELECT m.district_id,
    m.parent_id,
    m.district_name,
    m.district_full_name
   FROM m
  ORDER BY (to_number((m.parent_id)::text, '99999'::text)), (to_number((m.district_id)::text, '99999'::text));

