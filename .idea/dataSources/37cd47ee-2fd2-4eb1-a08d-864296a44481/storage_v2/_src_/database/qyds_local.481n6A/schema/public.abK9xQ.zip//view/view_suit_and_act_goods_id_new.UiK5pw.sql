create view view_suit_and_act_goods_id_new as
  SELECT suit.goods_id,
    suit.type,
    suit.brand_id,
    suit.goods_type_id,
    suit.goods_name,
    activity.actition_type,
    activity.activity_id,
    suit.goods_code,
    suit.search_key,
    suit.image_url_json,
    suit.update_time
   FROM ( SELECT master.goods_id,
            master.type,
            master.brand_id,
            master.goods_type_id,
            master.goods_name,
            master.goods_code,
            detail.search_key,
            detail.image_url_json,
            master.update_time
           FROM (gds_master master
             LEFT JOIN gds_detail detail ON ((((master.goods_id)::text = (detail.goods_id)::text) AND ((detail.deleted)::text = '0'::text))))
          WHERE (((master.type)::text = '30'::text) AND ((master.deleted)::text = '0'::text) AND ((master.is_onsell)::text = '0'::text))) suit,
    view_act_type_10 activity
UNION
 SELECT suit.goods_id,
    suit.type,
    suit.brand_id,
    suit.goods_type_id,
    suit.goods_name,
    activity.actition_type,
    activity.activity_id,
    suit.goods_code,
    suit.search_key,
    suit.image_url_json,
    suit.update_time
   FROM ( SELECT master.goods_id,
            master.type,
            master.brand_id,
            master.goods_type_id,
            master.goods_name,
            master.goods_code,
            detail.search_key,
            detail.image_url_json,
            master.update_time
           FROM (gds_master master
             LEFT JOIN gds_detail detail ON ((((master.goods_id)::text = (detail.goods_id)::text) AND ((detail.deleted)::text = '0'::text))))
          WHERE (((master.type)::text = '30'::text) AND ((master.deleted)::text = '0'::text) AND ((master.is_onsell)::text = '0'::text))) suit,
    view_act_type_20 activity
UNION
 SELECT suit.goods_id,
    suit.type,
    suit.brand_id,
    suit.goods_type_id,
    suit.goods_name,
    activity.actition_type,
    activity.activity_id,
    suit.goods_code,
    suit.search_key,
    suit.image_url_json,
    suit.update_time
   FROM ( SELECT master.goods_id,
            master.type,
            master.brand_id,
            master.goods_type_id,
            master.goods_name,
            master.goods_code,
            detail.search_key,
            detail.image_url_json,
            master.update_time
           FROM (gds_master master
             LEFT JOIN gds_detail detail ON ((((master.goods_id)::text = (detail.goods_id)::text) AND ((detail.deleted)::text = '0'::text))))
          WHERE (((master.type)::text = '30'::text) AND ((master.deleted)::text = '0'::text) AND ((master.is_onsell)::text = '0'::text))) suit,
    view_act_type_30 activity
UNION
 SELECT suit.goods_id,
    suit.type,
    suit.brand_id,
    suit.goods_type_id,
    suit.goods_name,
    activity.actition_type,
    activity.activity_id,
    suit.goods_code,
    suit.search_key,
    suit.image_url_json,
    suit.update_time
   FROM ( SELECT master.goods_id,
            master.type,
            master.brand_id,
            master.goods_type_id,
            master.goods_name,
            master.goods_code,
            detail.search_key,
            detail.image_url_json,
            master.update_time
           FROM (gds_master master
             LEFT JOIN gds_detail detail ON ((((master.goods_id)::text = (detail.goods_id)::text) AND ((detail.deleted)::text = '0'::text))))
          WHERE (((master.type)::text = '30'::text) AND ((master.deleted)::text = '0'::text) AND ((master.is_onsell)::text = '0'::text))) suit,
    view_act_type_40 activity
  WHERE ((activity.act_goods_id)::text = (suit.goods_id)::text);

