create view view_onsell_sku_select as
  SELECT master.goods_id,
    sku.price,
    sku.goods_sku_id AS skuid,
    bnk.new_count
   FROM ((gds_sku sku
     LEFT JOIN gds_master master ON (((sku.goods_id)::text = (master.goods_id)::text)))
     LEFT JOIN bnk_master bnk ON ((((bnk.sku)::text = (sku.goods_sku_id)::text) AND ((bnk.deleted)::text = '0'::text))))
  WHERE (((sku.deleted)::text = '0'::text) AND ((master.deleted)::text = '0'::text))
UNION ALL
 SELECT master.goods_id,
    erpgoods.price,
    erpgoods.sku AS skuid,
    sum(bnk.new_count) AS new_count
   FROM ((view_erp_goods erpgoods
     LEFT JOIN gds_master master ON (((erpgoods.goods_code)::text = (master.erp_goods_code)::text)))
     LEFT JOIN bnk_master bnk ON ((((bnk.sku)::text = (erpgoods.sku)::text) AND ((bnk.deleted)::text = '0'::text))))
  WHERE ((master.deleted)::text = '0'::text)
  GROUP BY master.goods_id, erpgoods.price, erpgoods.sku;

