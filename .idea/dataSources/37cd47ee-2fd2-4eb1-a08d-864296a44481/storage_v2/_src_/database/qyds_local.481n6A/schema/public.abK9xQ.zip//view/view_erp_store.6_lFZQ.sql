create view view_erp_store as
  SELECT s.store_code,
    s.store_name_en,
    s.store_name_cn,
    s.province_code,
    s.city_code,
    s.district_code,
    s.address,
    s.phone,
    s.comment,
    p.pname AS province_name,
    c.cname AS city_name,
    d.dname AS district_name,
    s.insert_time,
    s.update_time,
    s.bank_only,
    cd.display_cn AS bank_only_display
   FROM ((((erp_store s
     LEFT JOIN erp_province p ON (((p.pcode)::text = (s.province_code)::text)))
     LEFT JOIN erp_city c ON (((c.ccode)::text = (s.city_code)::text)))
     LEFT JOIN erp_district d ON (((d.dcode)::text = (s.district_code)::text)))
     LEFT JOIN com_code cd ON ((((cd.code)::text = 'ERP_BANK_ONLY'::text) AND ((s.bank_only)::text = (cd.value)::text))))
  ORDER BY s.province_code, s.city_code, s.district_code, s.store_code;

