CREATE VIEW view_erp_address_code AS SELECT p.pcode,
    p.pname,
    c.ccode,
    c.cname,
    d.dcode,
    d.dname
   FROM ((erp_district d
     LEFT JOIN erp_city c ON (((d.ccode)::text = (c.ccode)::text)))
     LEFT JOIN erp_province p ON (((p.pcode)::text = (c.pcode)::text)))
  ORDER BY d.dcode;
