CREATE VIEW view_approval_up_memberintwo AS SELECT m.member_id,
    m.member_name,
    m.telephone,
    max(o.amount_shop) AS max_point,
    m.point_cumulative AS all_point,
    m.member_level_id AS current_level_id,
    ( SELECT mmb_level_rule.member_level_code
           FROM mmb_level_rule
          WHERE ((mmb_level_rule.member_level_id)::text = '4ef890a4-e107-4df0-8114-c58cd7f29d73'::text)) AS approval_level_id
   FROM (ord_master o
     JOIN mmb_master m ON (((o.member_id)::text = (m.member_id)::text)))
  WHERE (((m.member_level_id)::text = '10'::text) AND ((o.amount_shop > (( SELECT mmb_level_rule.point_single
           FROM mmb_level_rule
          WHERE ((mmb_level_rule.member_level_code)::text = '30'::text)))::numeric) OR (m.point_cumulative > ( SELECT mmb_level_rule.point_cumulative
           FROM mmb_level_rule
          WHERE ((mmb_level_rule.member_level_code)::text = '30'::text)))))
  GROUP BY m.member_id;
