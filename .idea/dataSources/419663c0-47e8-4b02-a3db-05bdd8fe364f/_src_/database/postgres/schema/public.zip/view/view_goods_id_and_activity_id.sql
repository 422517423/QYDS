CREATE VIEW view_goods_id_and_activity_id AS SELECT g.goods_id,
    a.activity_id
   FROM gds_master g,
    act_master a
  WHERE (((((((((g.deleted)::text = '0'::text) AND ((g.is_onsell)::text = '0'::text)) AND ((a.deleted)::text = '0'::text)) AND ((a.unit)::text = '10'::text)) AND ((a.approve_status)::text = '20'::text)) AND (now() >= a.start_time)) AND (now() <= a.end_time)) AND ((a.goods_type)::text = '10'::text))
UNION ALL
 SELECT g.goods_id,
    a.activity_id
   FROM gds_master g,
    act_goods ag,
    act_master a
  WHERE ((((((((((((g.deleted)::text = '0'::text) AND ((g.is_onsell)::text = '0'::text)) AND ((ag.goods_id)::text = (g.goods_type_id)::text)) AND ((ag.activity_id)::text = (a.activity_id)::text)) AND ((ag.goods_type)::text = '20'::text)) AND ((a.deleted)::text = '0'::text)) AND ((a.unit)::text = '10'::text)) AND ((a.approve_status)::text = '20'::text)) AND (now() >= a.start_time)) AND (now() <= a.end_time)) AND ((a.goods_type)::text = '20'::text))
UNION ALL
 SELECT g.goods_id,
    a.activity_id
   FROM gds_master g,
    act_goods ag,
    act_master a
  WHERE ((((((((((((g.deleted)::text = '0'::text) AND ((g.is_onsell)::text = '0'::text)) AND ((ag.goods_id)::text = (g.brand_id)::text)) AND ((ag.activity_id)::text = (a.activity_id)::text)) AND ((ag.goods_type)::text = '30'::text)) AND ((a.deleted)::text = '0'::text)) AND ((a.unit)::text = '10'::text)) AND ((a.approve_status)::text = '20'::text)) AND (now() >= a.start_time)) AND (now() <= a.end_time)) AND ((a.goods_type)::text = '30'::text))
UNION ALL
 SELECT g.goods_id,
    a.activity_id
   FROM gds_master g,
    act_goods ag,
    act_master a
  WHERE ((((((((((((g.deleted)::text = '0'::text) AND ((g.is_onsell)::text = '0'::text)) AND ((ag.goods_id)::text = (g.goods_id)::text)) AND ((ag.activity_id)::text = (a.activity_id)::text)) AND ((ag.goods_type)::text = '40'::text)) AND ((a.deleted)::text = '0'::text)) AND ((a.unit)::text = '10'::text)) AND ((a.approve_status)::text = '20'::text)) AND (now() >= a.start_time)) AND (now() <= a.end_time)) AND ((a.goods_type)::text = '40'::text))
UNION ALL
 SELECT g.goods_id,
    a.activity_id
   FROM gds_master g,
    act_master a,
    ( SELECT act_goods.goods_id,
            act_goods.activity_id
           FROM act_goods
          WHERE ((act_goods.goods_type)::text = '50'::text)
          GROUP BY act_goods.goods_id, act_goods.activity_id) ag
  WHERE (((((((((((g.deleted)::text = '0'::text) AND ((g.is_onsell)::text = '0'::text)) AND ((ag.goods_id)::text = (g.goods_id)::text)) AND ((ag.activity_id)::text = (a.activity_id)::text)) AND ((a.deleted)::text = '0'::text)) AND ((a.unit)::text = '10'::text)) AND ((a.approve_status)::text = '20'::text)) AND (now() >= a.start_time)) AND (now() <= a.end_time)) AND (((((a.goods_type)::text = '50'::text) OR ((a.goods_type)::text = '60'::text)) OR ((a.goods_type)::text = '70'::text)) OR ((a.goods_type)::text = '80'::text)));
