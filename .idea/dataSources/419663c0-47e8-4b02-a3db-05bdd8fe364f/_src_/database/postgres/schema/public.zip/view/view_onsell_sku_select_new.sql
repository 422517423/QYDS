CREATE VIEW view_onsell_sku_select_new AS SELECT master.goods_id,
    sku.price,
    sku.goods_sku_id AS skuid
   FROM (gds_sku sku
     LEFT JOIN gds_master master ON (((sku.goods_id)::text = (master.goods_id)::text)))
  WHERE (((sku.deleted)::text = '0'::text) AND ((master.deleted)::text = '0'::text))
UNION ALL
 SELECT master.goods_id,
    erpgoods.price,
    erpgoods.sku AS skuid
   FROM (view_erp_goods erpgoods
     LEFT JOIN gds_master master ON (((erpgoods.goods_code)::text = (master.erp_goods_code)::text)))
  WHERE ((master.deleted)::text = '0'::text);
