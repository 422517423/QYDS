CREATE VIEW view_erp_bank_record AS SELECT r.recordid,
    r.erp_goods_code,
    g.goods_name_cn,
    r.erp_sku,
    g.color_code,
    c.color_name_cn AS color_name,
    g.size_type_code,
    s.type_name AS size_type_name,
    s.sort AS size_sort,
    g.size_code,
    s.size_full_name_cn AS size_name,
    r.erp_storeid,
    t.store_name_cn,
    r.inout_count,
    r.inout_time
   FROM ((((erp_bank_record r
     LEFT JOIN erp_goods g ON (((r.erp_sku)::text = (g.sku)::text)))
     LEFT JOIN erp_goods_color c ON (((g.color_code)::text = (c.color_code)::text)))
     LEFT JOIN erp_goods_size s ON ((((g.size_type_code)::text = (s.size_type_code)::text) AND ((g.size_code)::text = (s.size_code)::text))))
     LEFT JOIN erp_store t ON (((r.erp_storeid)::text = (t.store_code)::text)))
  ORDER BY g.goods_code, g.color_code, g.size_type_code, s.sort, r.erp_storeid, r.inout_time DESC;
