create function sync_erp_order() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
        IF (TG_OP = 'DELETE') THEN
            -- 根据原订单code删除统计表中数据
            delete from public.erp_order_statistics eos where eos.order_code = OLD.order_code;
            RETURN OLD;
        ELSIF (TG_OP = 'INSERT') THEN
            -- 当有数据插入时, 判断金额是否小于0, 小于0则将之前插入的同用户同金额的一条数据删除
            IF (NEW.amount < 0) THEN
                 delete from  public.erp_order_statistics eos where order_code = (
                    select order_code from
                    public.erp_order_statistics eos
                    where eos.member_code = NEW.member_code
                    and eos.amount = ABS(NEW.amount) limit 1
                );
            END IF;
            IF (NEW.amount > 0) THEN
                -- 大于0, 同步插入数据
                INSERT INTO public.erp_order_statistics SELECT NEW.*;
            END IF;
            RETURN NEW;
        END IF;
        RETURN NULL; -- result is ignored since this is an AFTER trigger
    END;
$$;
