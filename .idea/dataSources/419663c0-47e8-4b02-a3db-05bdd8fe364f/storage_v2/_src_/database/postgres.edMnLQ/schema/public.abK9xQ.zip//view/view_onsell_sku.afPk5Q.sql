create view view_onsell_sku as
  SELECT master.goods_id,
    master.type,
    master.brand_id,
    master.goods_type_id,
    master.is_onsell,
    master.goods_name,
    master.goods_code,
    master.goods_type_name_path,
    detail.search_key,
    detail.image_url_json,
    sku.goods_sku_id AS skuid,
    sku.sku AS skucontent,
    sku.colore_code AS color_code,
    sku.colore_name AS color_name,
    sku.price,
    sku.safe_bank,
    ''::character varying AS size_code,
    ''::character varying AS size_name,
    ''::text AS erpimg,
    bnk.new_count,
    master.update_time
   FROM (((gds_sku sku
     LEFT JOIN gds_master master ON (((sku.goods_id)::text = (master.goods_id)::text)))
     LEFT JOIN gds_detail detail ON (((detail.goods_id)::text = (master.goods_id)::text)))
     LEFT JOIN bnk_master bnk ON ((((bnk.sku)::text = (sku.goods_sku_id)::text) AND ((bnk.deleted)::text = '0'::text))))
  WHERE ((((sku.deleted)::text = '0'::text) AND ((master.deleted)::text = '0'::text)) AND ((detail.deleted)::text = '0'::text))
UNION ALL
 SELECT master.goods_id,
    master.type,
    erpgoods.brand_code AS brand_id,
    master.goods_type_id,
    master.is_onsell,
    master.goods_name,
    master.goods_code,
    master.goods_type_name_path,
    detail.search_key,
    detail.image_url_json,
    erpgoods.sku AS skuid,
    ''::text AS skucontent,
    erpgoods.color_code,
    erpgoods.color_name,
    erpgoods.price,
    999999 AS safe_bank,
    erpgoods.size_code,
    erpgoods.size_name,
    color.image_url_json AS erpimg,
    sum(bnk.new_count) AS new_count,
    master.update_time
   FROM ((((view_erp_goods erpgoods
     LEFT JOIN gds_master master ON (((erpgoods.goods_code)::text = (master.erp_goods_code)::text)))
     LEFT JOIN gds_detail detail ON (((detail.goods_id)::text = (master.goods_id)::text)))
     LEFT JOIN gds_coloreimage color ON (((((color.colore_code)::text = btrim((erpgoods.color_code)::text)) AND ((color.deleted)::text = '0'::text)) AND ((color.goods_id)::text = (master.goods_id)::text))))
     LEFT JOIN bnk_master bnk ON ((((bnk.sku)::text = (erpgoods.sku)::text) AND ((bnk.deleted)::text = '0'::text))))
  WHERE (((master.deleted)::text = '0'::text) AND ((detail.deleted)::text = '0'::text))
  GROUP BY master.goods_id, erpgoods.brand_code, detail.search_key, detail.image_url_json, erpgoods.sku, erpgoods.color_code, erpgoods.color_name, erpgoods.price, erpgoods.size_code, erpgoods.size_name, color.image_url_json;

