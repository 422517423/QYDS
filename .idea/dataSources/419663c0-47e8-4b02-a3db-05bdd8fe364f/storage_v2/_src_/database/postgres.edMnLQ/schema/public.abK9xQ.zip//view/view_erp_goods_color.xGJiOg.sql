create view view_erp_goods_color as
  SELECT g.goods_code,
    g.goods_name_cn,
    g.color_code,
    c.color_name_cn
   FROM (erp_goods g
     LEFT JOIN erp_goods_color c ON (((g.color_code)::text = (c.color_code)::text)))
  GROUP BY g.goods_code, g.goods_name_cn, g.color_code, c.color_name_cn
  ORDER BY g.goods_code, g.color_code;

