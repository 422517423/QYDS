create view view_ord_return_exchange_master as
  SELECT ore.rex_order_id,
    ore.order_id,
    ore.sub_order_id,
    ore.order_code,
    ore.member_id,
    ore.shop_id,
    om.amount_totle,
    om.amount_discount,
    om.point_count,
    om.amount_point,
    om.amount_coupon,
    om.pay_infact,
    om.order_time,
    om.pay_time,
    om.deliver_time,
    om.order_status,
    om.pay_status,
    om.deliver_status,
    co1.display_cn AS order_status_name,
    co2.display_cn AS pay_status_name,
    co3.display_cn AS deliver_status_name,
    ore.rex_status,
    ore.rex_type,
    ore.rex_mode,
    ore.rex_point,
    ore.refund_status,
    cc.display_cn AS rex_status_name,
    cc1.display_cn AS rex_type_name,
    cc2.display_cn AS rex_mode_name,
    cc3.display_cn AS rex_point_name,
    cc4.display_cn AS refund_status_name,
    ore.rex_store_id,
    ore.rex_store_name,
    ore.rex_member_id,
    m.member_name AS rex_member_name,
    ore.apply_time,
    ore.apply_comment,
    ore.apply_answer_user_id,
    ore.apply_answer_time,
    ore.apply_answer_comment,
    ore.return_goods_memberid,
    ore.return_goods_time,
    ore.return_express_id,
    ore.return_express_name,
    ore.return_express_no,
    ore.return_delivery_fee,
    ore.return_pay_delivery,
    ore.return_accept_user_id,
    ore.return_accept_time,
    ore.reback_express_id,
    ore.reback_express_name,
    ore.reback_express_no,
    ore.reback_delivery_fee,
    ore.reback_pay_delivery,
    ore.reback_accept_member_id,
    ore.reback_accept_time,
    ore.refund_goods,
    ore.delivery_fee,
    ore.refund_infact,
    ore.pay_account,
    ore.receipt_account,
    ore.refund_member_id,
    ore.refund_time
   FROM ((((((((((ord_return_exchange ore
     LEFT JOIN ord_master om ON (((om.order_id)::text = (ore.order_id)::text)))
     LEFT JOIN com_code cc ON ((((cc.code)::text = 'REX_STATUS'::text) AND ((cc.value)::text = (ore.rex_status)::text))))
     LEFT JOIN com_code cc1 ON ((((cc1.code)::text = 'REX_TYPE'::text) AND ((cc1.value)::text = (ore.rex_type)::text))))
     LEFT JOIN com_code cc2 ON ((((cc2.code)::text = 'REX_MODE'::text) AND ((cc2.value)::text = (ore.rex_mode)::text))))
     LEFT JOIN com_code cc3 ON ((((cc3.code)::text = 'REX_POINT'::text) AND ((cc3.value)::text = (ore.rex_point)::text))))
     LEFT JOIN com_code cc4 ON ((((cc4.code)::text = 'REFUND_STATUS'::text) AND ((cc4.value)::text = (ore.refund_status)::text))))
     LEFT JOIN com_code co1 ON ((((co1.code)::text = 'ORDER_STATUS'::text) AND ((co1.value)::text = (om.order_status)::text))))
     LEFT JOIN com_code co2 ON ((((co2.code)::text = 'PAY_STATUE'::text) AND ((co2.value)::text = (om.pay_status)::text))))
     LEFT JOIN com_code co3 ON ((((co3.code)::text = 'DELIVER_STATUS'::text) AND ((co3.value)::text = (om.deliver_status)::text))))
     LEFT JOIN mmb_master m ON (((m.member_id)::text = (ore.rex_member_id)::text)))
  ORDER BY ore.rex_status, ore.apply_time DESC;

