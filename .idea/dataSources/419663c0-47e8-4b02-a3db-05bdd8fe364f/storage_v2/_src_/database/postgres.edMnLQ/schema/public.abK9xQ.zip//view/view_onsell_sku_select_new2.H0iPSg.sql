create view view_onsell_sku_select_new2 as
  SELECT master.goods_id,
    master.deleted,
    master.is_onsell,
    master.type,
    sku.price,
    ''::character varying AS size_type_code,
    sku.size_code,
    sku.goods_sku_id AS skuid
   FROM (gds_sku sku
     LEFT JOIN gds_master master ON (((sku.goods_id)::text = (master.goods_id)::text)))
  WHERE (((sku.deleted)::text = '0'::text) AND ((master.deleted)::text = '0'::text))
UNION ALL
 SELECT master.goods_id,
    master.deleted,
    master.is_onsell,
    master.type,
    erpgoods.price,
    erpgoods.size_type_code,
    erpgoods.size_code,
    erpgoods.sku AS skuid
   FROM (erp_goods erpgoods
     LEFT JOIN gds_master master ON (((erpgoods.goods_code)::text = (master.erp_goods_code)::text)))
  WHERE ((master.deleted)::text = '0'::text);

