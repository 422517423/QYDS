create view view_erp_store_org as
  SELECT erp_store.store_code AS org_id,
    '00000000' AS shop_id,
    ( SELECT shp_org.org_id
           FROM shp_org
          WHERE ((shp_org.org_code)::text = 'store'::text)) AS orgid_parent,
    row_number() OVER () AS sort,
    '20' AS org_type,
    erp_store.store_code AS org_code,
    erp_store.store_code AS erp_store_id,
    erp_store.store_name_cn AS org_short_name,
    erp_store.store_name_cn AS org_name,
    (
        CASE
            WHEN (erp_store.phone IS NOT NULL) THEN (('电话：'::text || (erp_store.phone)::text) || '  '::text)
            ELSE ''::text
        END ||
        CASE
            WHEN (erp_store.address IS NOT NULL) THEN ('地址：'::text || (erp_store.address)::text)
            ELSE ''::text
        END) AS comment
   FROM erp_store;

