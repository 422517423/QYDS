create view view_test as
  SELECT master.goods_id,
    sku.price,
    sku.goods_sku_id AS skuid,
    bnk.new_count
   FROM ((gds_sku sku
     JOIN gds_master master ON (((sku.goods_id)::text = (master.goods_id)::text)))
     JOIN bnk_master bnk ON ((((bnk.sku)::text = (sku.goods_sku_id)::text) AND ((bnk.deleted)::text = '0'::text))))
  WHERE (((sku.deleted)::text = '0'::text) AND ((master.deleted)::text = '0'::text))
UNION ALL
 SELECT master.goods_id,
    erpgoods.price,
    erpgoods.sku AS skuid,
    sum(bnk.new_count) AS new_count
   FROM ((( SELECT view_erp_goods.price,
            view_erp_goods.sku,
            view_erp_goods.goods_code
           FROM view_erp_goods) erpgoods
     JOIN ( SELECT gds_master.goods_id,
            gds_master.erp_goods_code,
            gds_master.deleted
           FROM gds_master
          WHERE ((gds_master.deleted)::text = '0'::text)) master ON (((erpgoods.goods_code)::text = (master.erp_goods_code)::text)))
     JOIN ( SELECT bnk_master.sku,
            bnk_master.deleted,
            bnk_master.new_count
           FROM bnk_master
          WHERE ((bnk_master.deleted)::text = '0'::text)) bnk ON (((bnk.sku)::text = (erpgoods.sku)::text)))
  GROUP BY master.goods_id, erpgoods.price, erpgoods.sku;

