create view view_approval_up_memberintwo as
  SELECT a.member_id,
    a.member_name,
    a.telephone,
    max(a.a_total) AS max_point,
        CASE
            WHEN (sum(a.a_total) IS NOT NULL) THEN sum(a.a_total)
            ELSE (0)::numeric
        END AS all_point,
    a.member_level_id AS current_level_id,
    ( SELECT mmb_level_rule.member_level_code
           FROM mmb_level_rule
          WHERE ((mmb_level_rule.member_level_id)::text = '4ef890a4-e107-4df0-8114-c58cd7f29d73'::text)) AS approval_level_id,
    a.y_time
   FROM ( SELECT m.member_id,
            m.member_name,
            m.telephone,
            m.member_level_id,
            om.pay_infact AS a_total,
            to_char(( SELECT om.pay_time), 'yyyy'::text) AS y_time
           FROM (mmb_master m
             JOIN ord_master om ON (((om.member_id)::text = (m.member_id)::text)))
          WHERE (((om.order_time + '15 days'::interval) < now()) AND (((((m.member_level_id)::text = '10'::text) AND ((om.pay_status)::text = '20'::text)) AND (to_char(( SELECT om.pay_time), 'yyyy'::text) >= to_char(( SELECT ((now())::timestamp without time zone + '-1 years'::interval)), 'yyyy'::text))) AND (to_char(( SELECT om.pay_time), 'yyyy'::text) <= to_char(( SELECT (now())::timestamp without time zone AS now), 'yyyy'::text))))
        UNION ALL
         SELECT m.member_id,
            m.member_name,
            m.telephone,
            m.member_level_id,
            eos.amount AS a_total,
            to_char(( SELECT eos.order_time), 'yyyy'::text) AS y_time
           FROM (mmb_master m
             JOIN erp_order_statistics eos ON (((eos.member_code)::text = (m.telephone)::text)))
          WHERE (((eos.order_time + '15 days'::interval) < now()) AND ((((m.member_level_id)::text = '10'::text) AND (to_char(( SELECT eos.order_time), 'yyyy'::text) >= to_char(( SELECT ((now())::timestamp without time zone + '-1 years'::interval)), 'yyyy'::text))) AND (to_char(( SELECT eos.order_time), 'yyyy'::text) <= to_char(( SELECT (now())::timestamp without time zone AS now), 'yyyy'::text))))) a
  GROUP BY a.member_id, a.y_time, a.member_name, a.telephone, a.member_level_id
 HAVING ((
        CASE
            WHEN (sum(a.a_total) IS NOT NULL) THEN sum(a.a_total)
            ELSE (0)::numeric
        END >= (3000)::numeric) OR (max(a.a_total) >= (1500)::numeric));

