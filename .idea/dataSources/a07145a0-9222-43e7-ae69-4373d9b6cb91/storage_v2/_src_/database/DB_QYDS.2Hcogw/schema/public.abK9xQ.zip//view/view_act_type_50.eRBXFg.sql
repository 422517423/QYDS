create view view_act_type_50 as
  SELECT am.activity_id,
    am.activity_name,
    am.goods_type,
    am.member_type,
    template.actition_type,
    ag.goods_id AS act_goods_id,
    ag.sku_id AS act_sku_id
   FROM ((act_master am
     LEFT JOIN act_goods ag ON (((am.activity_id)::text = (ag.activity_id)::text)))
     LEFT JOIN act_template template ON (((template.temp_id)::text = (am.temp_id)::text)))
  WHERE (((((((ag.goods_type)::text = '50'::text) AND ((am.unit)::text = '10'::text)) AND ((am.approve_status)::text = '20'::text)) AND (am.start_time <= now())) AND (am.end_time >= now())) AND ((am.deleted)::text = '0'::text));

