create view view_erp_goods_goods_master as
  SELECT DISTINCT erpgoods.goods_code AS goods_id,
    '00000000'::text AS shop_id,
    '10'::text AS type,
    (erpgoods.brand_code)::text AS brand_id,
    ''::text AS goods_type_id,
    ''::text AS erp_style_no,
    erpgoods.goods_code,
    erpgoods.goods_name_cn AS goods_name,
    erpgoods.goods_code AS erp_goods_code,
    erpgoods.style_name AS erp_goods_name,
    erpgoods.brand_name AS erp_brand_name,
    '10'::text AS maintain_status,
    '1'::text AS is_onsell,
    '1'::text AS is_waste,
    '0'::text AS deleted,
    ''::text AS update_user_id,
    now() AS update_time,
    ''::text AS insert_user_id,
    now() AS insert_time,
    0 AS sort,
    master.goods_type_id_path
   FROM (erp_goods erpgoods
     LEFT JOIN gds_master master ON (((erpgoods.goods_code)::text = (master.erp_goods_code)::text)))
  WHERE (((erpgoods.deleted)::text = '0'::text) AND (master.erp_goods_code IS NULL))
UNION ALL
 SELECT gds.goods_id,
    gds.shop_id,
    gds.type,
    gds.brand_id,
    gds.goods_type_id,
    gds.erp_style_no,
    gds.goods_code,
    gds.goods_name,
    gds.erp_goods_code,
    gds.erp_goods_name,
    ''::character varying AS erp_brand_name,
    gds.maintain_status,
    gds.is_onsell,
    gds.is_waste,
    gds.deleted,
    gds.update_user_id,
    gds.update_time,
    gds.insert_user_id,
    gds.insert_time,
    gds.sort,
    gds.goods_type_id_path
   FROM gds_master gds
  WHERE ((gds.deleted)::text = '0'::text);

